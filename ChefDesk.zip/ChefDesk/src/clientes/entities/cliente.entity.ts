export class Cliente {}

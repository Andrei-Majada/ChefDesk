export class PersonalizacoesServico {}

export class pratosCardapio {}
